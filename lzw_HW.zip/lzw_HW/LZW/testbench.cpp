#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <unistd.h>
#include <vector>
#include "lzw_headers.h"
#include <stdio.h>
#include<string>


static int encoding_check(unsigned char lhw[], unsigned char lsw[], int stringlength) {

	int count =0;

	for(int i = 0 ; i<stringlength ; i++  )
	{
		if(lhw[i] == lsw[i])
		{
			count++;
		} else {
			std::cout << "i: " << i << " SW: " << (int) lsw[i] << " HW: " << (int) lhw[i] << std::endl;
		}
	}
  return count;

}

int main(int argc, char *argv[]) {

	// Declaring Output Variablesstd::cout << "i: " << i << " SW: std::cout << "i: " << i << " SW: " << (int) lsw[i] << " HW: " << (int) lhw[i] << std::endl;" << (int) lsw[i] << " HW: " << (int) lhw[i] << std::endl;
		char in[] = "The grown-ups' response, this time, was to advise me to lay aside my drawings of boa constrictors, whether from the inside or the outside, and devote myself instead to geography, history, arithmetic, and grammar. That is why, at the age of six, I gave up what might have been a magnificent career as a painter. I had been disheartened by the failure of my Drawing Number One and my Drawing Number Two. Grown-ups never understand anything by themselves, and it is tiresome for children to be always and forever explaining things to them.\nSo then I chose another profession, and learned to pilot airplanes. I have flown a little over all parts of the world; and it is true that geography has been very useful to me. At a glance I can distinguish China from Arizona. If one gets lost in the night, such knowledge is valuable.";
		unsigned char lhw_out[13316];
		unsigned char lsw_out[13316];

		int chunksize;
		int check = 0;
		int stringlength = strlen(in)+1;

		printf("%d\n",stringlength);

		// Calling LZW_sw

		//run_LZW(lsw_in,lsw_out);

		int lengthSW = run_LZW((unsigned char*) in, stringlength, lsw_out,0);
		//int lengthHW = run_LZW_hw ((unsigned char*) in, stringlength, lhw_out, 0);
		lzw_hw_streams((unsigned char*) in, stringlength, lhw_out);

		int lengthHW = (lhw_out[3] << 24) | (lhw_out[2] << 16) | (lhw_out[1] << 8) | lhw_out[0];

		std::cout << "SW: " << lengthSW << ", HW: " << lengthHW << std::endl;

		if (lengthSW == lengthHW) {
			check = encoding_check(lsw_out, &lhw_out[4], lengthSW);
		} else {
			return 1;
		}

	std::cout << "TEST " << ((check==lengthSW) ? "PASSED" : "FAILED") << std::endl;

	// Calling LZW_hw

	//Comparing Result of LZW_sw and LZW_hw
	if (check == lengthSW) {
		return 0;
	} else {
		return 1;
	}
}

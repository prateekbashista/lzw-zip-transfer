#ifndef LZW_HEADERS_
#define LZW_HEADERS_
#include <hls_stream.h>


int run_LZW(unsigned char input_chunk[], int chunkSize, unsigned char output[], int output_ptr);
//int lhw(placeholder for hardware version)
//int run_LZW_hw (unsigned char input_chunk[], int chunkSize, unsigned char output[], int output_ptr);
void lzw_hw_streams(unsigned char input_chunk[], int chunkSize, unsigned char output[]);

#endif

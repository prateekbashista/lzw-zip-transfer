//WORKING COPY OF LZW ALGORITHM IN CPP DIVIDED IN LOAD STORE COMPUTE FORMAT
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <hls_stream.h>
#define LZW_NUM_BUCKETS 16384
#define HASH_BITMASK 0x3FFF
#define LZW_BUCKET_DEPTH 4

void put(uint64_t hash_table[][LZW_BUCKET_DEPTH], uint16_t curr, uint8_t input, uint16_t next) {
    uint64_t key = (curr << 8) | input;
    int hash = key & HASH_BITMASK;
    key = (key << 13) | (next & 0x1FFF);
    for (char i = 0; i < LZW_BUCKET_DEPTH; i++) {
        if (hash_table[hash][i] == (uint64_t) 0) {
            hash_table[hash][i] = key;
            return;
        }
    }
}

uint16_t get(uint64_t hash_table[][LZW_BUCKET_DEPTH], uint16_t curr, uint8_t input) {
    uint64_t key = (curr << 8) | input;
    int hash = key & HASH_BITMASK;
    for (char i = 0; i < LZW_BUCKET_DEPTH; i++) {
        if ((hash_table[hash][i] >> 13) == key) {
            return (hash_table[hash][i] & 0x1FFF);
        }
    }
    return 0x1FFF;
}

void lzw_hw_compute(hls::stream<unsigned char> &instream, int chunkSize, hls::stream<uint16_t> &outstream) {
    // Key = 13b current character + 8b next character
    // Value = 13b new character, or -1 if none exists
    // Total = 34b per entry
    uint64_t hash_table [LZW_NUM_BUCKETS][LZW_BUCKET_DEPTH];

	#pragma HLS array_partition cyclic factor=8 dim=1 variable=hash_table

    for (int i = 0; i < LZW_NUM_BUCKETS; i++) {
	#pragma HLS unroll factor=8
        for (int j = 0; j < LZW_BUCKET_DEPTH; j++) {
            hash_table[i][j] = 0;
        }
    }
    int num;
    int index;

    // Insert the first 256 entries into the dictionary
    for (num = 0; num < 256; num++) {
	#pragma HLS unroll
        put(hash_table, 0x1FFF, num, num); // Encode the current character as -1, next as itself
    }

    // Setup memory for string processing
    uint16_t prev_str = 0x1FFF;
    uint8_t input_char = instream.read();
    uint8_t next_char = 0;
    uint16_t curr_str = get(hash_table, prev_str, input_char);
    unsigned char state = 0;

    // Compress the input chunk
    for (index = 0; index < chunkSize - 1; index++) {
        next_char = instream.read();
        uint16_t temp_str = get(hash_table, curr_str, next_char);
        if (temp_str != 0x1fff) {
            prev_str = curr_str;
            curr_str = temp_str;
        } else {
            // Output the code for curr_str
            outstream.write(curr_str);

            // Insert the new string into the dictionary
            put(hash_table, curr_str, next_char, (uint16_t) num++);
            prev_str = 0x1FFF;
            curr_str = next_char;
        }
    }

    // Output the last code, if necessary
    if (prev_str != 0x1FFF) {
        uint16_t code = get(hash_table, prev_str, next_char);
        outstream.write(code);
    }

    // Indicate that the compression is complete
    outstream.write(0xFFFF);
}

void lzw_hw_load(unsigned char input_chunk[], int chunkSize, hls::stream<unsigned char> &instream) {
	for (int i = 0; i < chunkSize; i++) {
		instream.write(input_chunk[i]);
	}
}

void lzw_hw_bitpack(hls::stream<uint16_t> &midstream, hls::stream<uint16_t> &outstream)
{
	uint32_t code = midstream.read();
	uint8_t state = 0;

	unsigned char temp = 0;
	for (int i = 0; i < 8192; i++) {
	#pragma HLS pipeline
		code = code & 0x1FFF;
	    	switch (state) {
			case 0:
			    // Output: 8 | 5 _ _ _
			    code = code << 3;
			    outstream.write((unsigned char) ((code >> 8) & 0xFF));
			    temp = (unsigned char) (code & 0xFF);
			    state = 1;
			    break;
			case 1:
			    // Output: _ _ _ _ _ 3 | 8 | 2 _ _ _ _ _ _
			    code = code << 6;
			    outstream.write((unsigned char) (temp | ((code >> 16) & 0x07)));
			    outstream.write((unsigned char) ((code >> 8) & 0xFF));
			    temp = (unsigned char) (code & 0xFF);
			    state = 2;
			    break;
			case 2:
			    // Output: _ _ 6 | 7 _
			    code = code << 1;
			    outstream.write((unsigned char) (temp | ((code >> 8) & 0x3F)));
			    temp = (unsigned char) (code & 0xFF);
			    state = 3;
			    break;
			case 3:
			    // Output: _ _ _ _ _ _ _ 1 | 8 | 4 _ _ _ _
			    code = code << 4;
			    outstream.write((unsigned char) (temp | ((code >> 16) & 0x01)));
			    outstream.write((unsigned char) ((code >> 8) & 0xFF));
			    temp = (unsigned char) (code & 0xFF);
			    state = 4;
			    break;
			case 4:
			    // Output: _ _ _ _ 4 | 8 | 1 _ _ _ _ _ _ _
			    code = code << 7;
			    outstream.write((unsigned char) (temp | ((code >> 16) & 0x0F)));
			    outstream.write((unsigned char) ((code >> 8) & 0xFF));
			    temp = (unsigned char) (code & 0xFF);
			    state = 5;
			    break;
			case 5:
			    // Output: _ 7 | 6 _ _
			    code = code << 2;
			    outstream.write((unsigned char) (temp | ((code >> 8) & 0x7F)));
			    temp = (unsigned char) (code & 0xFF);
			    state = 6;
			    break;
			case 6:
			    // Output: _ _ _ _ _ _ 2 | 8 | 3 _ _ _ _ _
			    code = code << 5;
			    outstream.write((unsigned char) (temp | ((code >> 16) & 0x03)));
			    outstream.write((unsigned char) ((code >> 8) & 0xFF));
			    temp = (unsigned char) (code & 0xFF);
			    state = 7;
			    break;
			case 7:
			    // Output: _ 5 | 8
				outstream.write((unsigned char) (temp | ((code >> 8) & 0x1F)));
				outstream.write((unsigned char) (code & 0xFF));
			    state = 0;
			    break;
	    	}
	    	code = midstream.read();
	    	if (code == 0xFFFF) {
	    		break;
	    	}
	}

	if (state != 0) {
		outstream.write(temp);
	}

	outstream.write(0xFFFF);
}

void lzw_hw_store(hls::stream<uint16_t> &outstream, unsigned char output[]) {
	int byte_count;
	uint16_t temp;
	for (byte_count = 4; byte_count < 13316; byte_count++) {
		temp = outstream.read();
		if (temp == 0xFFFF) {
			break;
		}
		output[byte_count] = temp & 0xFF;
	}

	byte_count -= 4;
	output[0] = byte_count & 0xFF;
	output[1] = (byte_count >> 8) & 0xFF;
	output[2] = (byte_count >> 16) & 0xFF;
	output[3] = (byte_count >> 24) & 0xFF;
}


void lzw_hw_streams(unsigned char input_chunk[], int chunkSize, unsigned char output[])
{
#pragma HLS DATAFLOW
	hls::stream<unsigned char, 8192> instream;
  	hls::stream<uint16_t, 8192> midstream;
  	hls::stream<uint16_t, 13316> outstream;

  	#pragma HLS INTERFACE m_axi port=input_chunk offset=slave bundle=p0 depth=10000
	#pragma HLS INTERFACE m_axi port=output offset=slave bundle=p1 depth=20000


  	lzw_hw_load(input_chunk, chunkSize, instream);
  	lzw_hw_compute(instream, chunkSize, midstream);
  	lzw_hw_bitpack(midstream, outstream);
  	lzw_hw_store(outstream, output);

}



#include <systemc>
#include <vector>
#include <iostream>
#include "hls_stream.h"
#include "ap_int.h"
#include "ap_fixed.h"
using namespace std;
using namespace sc_dt;
class AESL_RUNTIME_BC {
  public:
    AESL_RUNTIME_BC(const char* name) {
      file_token.open( name);
      if (!file_token.good()) {
        cout << "Failed to open tv file " << name << endl;
        exit (1);
      }
      file_token >> mName;//[[[runtime]]]
    }
    ~AESL_RUNTIME_BC() {
      file_token.close();
    }
    int read_size () {
      int size = 0;
      file_token >> mName;//[[transaction]]
      file_token >> mName;//transaction number
      file_token >> mName;//pop_size
      size = atoi(mName.c_str());
      file_token >> mName;//[[/transaction]]
      return size;
    }
  public:
    fstream file_token;
    string mName;
};
extern "C" void lzw_hw_streams(char*, int*, int, int, int);
extern "C" void apatb_lzw_hw_streams_hw(volatile void * __xlx_apatb_param_input_chunk, int __xlx_apatb_param_chunkSize, volatile void * __xlx_apatb_param_output) {
  // Collect __xlx_input_chunk__tmp_vec
  vector<sc_bv<8> >__xlx_input_chunk__tmp_vec;
  for (int j = 0, e = 10000; j != e; ++j) {
    __xlx_input_chunk__tmp_vec.push_back(((char*)__xlx_apatb_param_input_chunk)[j]);
  }
  int __xlx_size_param_input_chunk = 10000;
  int __xlx_offset_param_input_chunk = 0;
  int __xlx_offset_byte_param_input_chunk = 0*1;
  char* __xlx_input_chunk__input_buffer= new char[__xlx_input_chunk__tmp_vec.size()];
  for (int i = 0; i < __xlx_input_chunk__tmp_vec.size(); ++i) {
    __xlx_input_chunk__input_buffer[i] = __xlx_input_chunk__tmp_vec[i].range(7, 0).to_uint64();
  }
  // Collect __xlx_output__tmp_vec
  vector<sc_bv<32> >__xlx_output__tmp_vec;
  for (int j = 0, e = 5000; j != e; ++j) {
    __xlx_output__tmp_vec.push_back(((int*)__xlx_apatb_param_output)[j]);
  }
  int __xlx_size_param_output = 5000;
  int __xlx_offset_param_output = 0;
  int __xlx_offset_byte_param_output = 0*4;
  int* __xlx_output__input_buffer= new int[__xlx_output__tmp_vec.size()];
  for (int i = 0; i < __xlx_output__tmp_vec.size(); ++i) {
    __xlx_output__input_buffer[i] = __xlx_output__tmp_vec[i].range(31, 0).to_uint64();
  }
  // DUT call
  lzw_hw_streams(__xlx_input_chunk__input_buffer, __xlx_output__input_buffer, __xlx_offset_byte_param_input_chunk, __xlx_apatb_param_chunkSize, __xlx_offset_byte_param_output);
// print __xlx_apatb_param_input_chunk
  sc_bv<8>*__xlx_input_chunk_output_buffer = new sc_bv<8>[__xlx_size_param_input_chunk];
  for (int i = 0; i < __xlx_size_param_input_chunk; ++i) {
    __xlx_input_chunk_output_buffer[i] = __xlx_input_chunk__input_buffer[i+__xlx_offset_param_input_chunk];
  }
  for (int i = 0; i < __xlx_size_param_input_chunk; ++i) {
    ((char*)__xlx_apatb_param_input_chunk)[i] = __xlx_input_chunk_output_buffer[i].to_uint64();
  }
// print __xlx_apatb_param_output
  sc_bv<32>*__xlx_output_output_buffer = new sc_bv<32>[__xlx_size_param_output];
  for (int i = 0; i < __xlx_size_param_output; ++i) {
    __xlx_output_output_buffer[i] = __xlx_output__input_buffer[i+__xlx_offset_param_output];
  }
  for (int i = 0; i < __xlx_size_param_output; ++i) {
    ((int*)__xlx_apatb_param_output)[i] = __xlx_output_output_buffer[i].to_uint64();
  }
}

// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XLZW_HW_STREAMS_H
#define XLZW_HW_STREAMS_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlzw_hw_streams_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XLzw_hw_streams_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLzw_hw_streams;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLzw_hw_streams_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLzw_hw_streams_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLzw_hw_streams_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLzw_hw_streams_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XLzw_hw_streams_Initialize(XLzw_hw_streams *InstancePtr, u16 DeviceId);
XLzw_hw_streams_Config* XLzw_hw_streams_LookupConfig(u16 DeviceId);
int XLzw_hw_streams_CfgInitialize(XLzw_hw_streams *InstancePtr, XLzw_hw_streams_Config *ConfigPtr);
#else
int XLzw_hw_streams_Initialize(XLzw_hw_streams *InstancePtr, const char* InstanceName);
int XLzw_hw_streams_Release(XLzw_hw_streams *InstancePtr);
#endif

void XLzw_hw_streams_Start(XLzw_hw_streams *InstancePtr);
u32 XLzw_hw_streams_IsDone(XLzw_hw_streams *InstancePtr);
u32 XLzw_hw_streams_IsIdle(XLzw_hw_streams *InstancePtr);
u32 XLzw_hw_streams_IsReady(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_Continue(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_EnableAutoRestart(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_DisableAutoRestart(XLzw_hw_streams *InstancePtr);

void XLzw_hw_streams_Set_input_chunk(XLzw_hw_streams *InstancePtr, u64 Data);
u64 XLzw_hw_streams_Get_input_chunk(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_Set_chunkSize(XLzw_hw_streams *InstancePtr, u32 Data);
u32 XLzw_hw_streams_Get_chunkSize(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_Set_output_r(XLzw_hw_streams *InstancePtr, u64 Data);
u64 XLzw_hw_streams_Get_output_r(XLzw_hw_streams *InstancePtr);

void XLzw_hw_streams_InterruptGlobalEnable(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_InterruptGlobalDisable(XLzw_hw_streams *InstancePtr);
void XLzw_hw_streams_InterruptEnable(XLzw_hw_streams *InstancePtr, u32 Mask);
void XLzw_hw_streams_InterruptDisable(XLzw_hw_streams *InstancePtr, u32 Mask);
void XLzw_hw_streams_InterruptClear(XLzw_hw_streams *InstancePtr, u32 Mask);
u32 XLzw_hw_streams_InterruptGetEnabled(XLzw_hw_streams *InstancePtr);
u32 XLzw_hw_streams_InterruptGetStatus(XLzw_hw_streams *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif

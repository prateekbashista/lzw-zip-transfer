# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
# Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/mnt/pollux/software/xilinx/2020.2/Vivado/2020.2/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xczu3eg-sbva484-1-i ../xilinx_com_hls_lzw_hw_streams_1_0.zip

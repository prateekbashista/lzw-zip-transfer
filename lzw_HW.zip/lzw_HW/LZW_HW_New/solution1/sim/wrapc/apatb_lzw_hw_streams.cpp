#include <systemc>
#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <stdint.h>
#include "SysCFileHandler.h"
#include "ap_int.h"
#include "ap_fixed.h"
#include <complex>
#include <stdbool.h>
#include "autopilot_cbe.h"
#include "hls_stream.h"
#include "hls_half.h"
#include "hls_signal_handler.h"

using namespace std;
using namespace sc_core;
using namespace sc_dt;

// wrapc file define:
#define AUTOTB_TVIN_p0 "../tv/cdatafile/c.lzw_hw_streams.autotvin_p0.dat"
#define AUTOTB_TVOUT_p0 "../tv/cdatafile/c.lzw_hw_streams.autotvout_p0.dat"
// wrapc file define:
#define AUTOTB_TVIN_p1 "../tv/cdatafile/c.lzw_hw_streams.autotvin_p1.dat"
#define AUTOTB_TVOUT_p1 "../tv/cdatafile/c.lzw_hw_streams.autotvout_p1.dat"
// wrapc file define:
#define AUTOTB_TVIN_input_chunk "../tv/cdatafile/c.lzw_hw_streams.autotvin_input_chunk.dat"
#define AUTOTB_TVOUT_input_chunk "../tv/cdatafile/c.lzw_hw_streams.autotvout_input_chunk.dat"
// wrapc file define:
#define AUTOTB_TVIN_chunkSize "../tv/cdatafile/c.lzw_hw_streams.autotvin_chunkSize.dat"
#define AUTOTB_TVOUT_chunkSize "../tv/cdatafile/c.lzw_hw_streams.autotvout_chunkSize.dat"
// wrapc file define:
#define AUTOTB_TVIN_output "../tv/cdatafile/c.lzw_hw_streams.autotvin_output_r.dat"
#define AUTOTB_TVOUT_output "../tv/cdatafile/c.lzw_hw_streams.autotvout_output_r.dat"

#define INTER_TCL "../tv/cdatafile/ref.tcl"

// tvout file define:
#define AUTOTB_TVOUT_PC_p0 "../tv/rtldatafile/rtl.lzw_hw_streams.autotvout_p0.dat"
// tvout file define:
#define AUTOTB_TVOUT_PC_p1 "../tv/rtldatafile/rtl.lzw_hw_streams.autotvout_p1.dat"
// tvout file define:
#define AUTOTB_TVOUT_PC_input_chunk "../tv/rtldatafile/rtl.lzw_hw_streams.autotvout_input_chunk.dat"
// tvout file define:
#define AUTOTB_TVOUT_PC_chunkSize "../tv/rtldatafile/rtl.lzw_hw_streams.autotvout_chunkSize.dat"
// tvout file define:
#define AUTOTB_TVOUT_PC_output "../tv/rtldatafile/rtl.lzw_hw_streams.autotvout_output_r.dat"

class INTER_TCL_FILE {
  public:
INTER_TCL_FILE(const char* name) {
  mName = name; 
  p0_depth = 0;
  p1_depth = 0;
  input_chunk_depth = 0;
  chunkSize_depth = 0;
  output_depth = 0;
  trans_num =0;
}
~INTER_TCL_FILE() {
  mFile.open(mName);
  if (!mFile.good()) {
    cout << "Failed to open file ref.tcl" << endl;
    exit (1); 
  }
  string total_list = get_depth_list();
  mFile << "set depth_list {\n";
  mFile << total_list;
  mFile << "}\n";
  mFile << "set trans_num "<<trans_num<<endl;
  mFile.close();
}
string get_depth_list () {
  stringstream total_list;
  total_list << "{p0 " << p0_depth << "}\n";
  total_list << "{p1 " << p1_depth << "}\n";
  total_list << "{input_chunk " << input_chunk_depth << "}\n";
  total_list << "{chunkSize " << chunkSize_depth << "}\n";
  total_list << "{output_r " << output_depth << "}\n";
  return total_list.str();
}
void set_num (int num , int* class_num) {
  (*class_num) = (*class_num) > num ? (*class_num) : num;
}
void set_string(std::string list, std::string* class_list) {
  (*class_list) = list;
}
  public:
    int p0_depth;
    int p1_depth;
    int input_chunk_depth;
    int chunkSize_depth;
    int output_depth;
    int trans_num;
  private:
    ofstream mFile;
    const char* mName;
};

static void RTLOutputCheckAndReplacement(std::string &AESL_token, std::string PortName) {
  bool no_x = false;
  bool err = false;

  no_x = false;
  // search and replace 'X' with '0' from the 3rd char of token
  while (!no_x) {
    size_t x_found = AESL_token.find('X', 0);
    if (x_found != string::npos) {
      if (!err) { 
        cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'X' on port" 
             << PortName << ", possible cause: There are uninitialized variables in the C design."
             << endl; 
        err = true;
      }
      AESL_token.replace(x_found, 1, "0");
    } else
      no_x = true;
  }
  no_x = false;
  // search and replace 'x' with '0' from the 3rd char of token
  while (!no_x) {
    size_t x_found = AESL_token.find('x', 2);
    if (x_found != string::npos) {
      if (!err) { 
        cerr << "WARNING: [SIM 212-201] RTL produces unknown value 'x' on port" 
             << PortName << ", possible cause: There are uninitialized variables in the C design."
             << endl; 
        err = true;
      }
      AESL_token.replace(x_found, 1, "0");
    } else
      no_x = true;
  }
}
extern "C" void lzw_hw_streams_hw_stub_wrapper(volatile void *, int, volatile void *);

extern "C" void apatb_lzw_hw_streams_hw(volatile void * __xlx_apatb_param_input_chunk, int __xlx_apatb_param_chunkSize, volatile void * __xlx_apatb_param_output) {
  refine_signal_handler();
  fstream wrapc_switch_file_token;
  wrapc_switch_file_token.open(".hls_cosim_wrapc_switch.log");
  int AESL_i;
  if (wrapc_switch_file_token.good())
  {

    CodeState = ENTER_WRAPC_PC;
    static unsigned AESL_transaction_pc = 0;
    string AESL_token;
    string AESL_num;{
      static ifstream rtl_tv_out_file;
      if (!rtl_tv_out_file.is_open()) {
        rtl_tv_out_file.open(AUTOTB_TVOUT_PC_p1);
        if (rtl_tv_out_file.good()) {
          rtl_tv_out_file >> AESL_token;
          if (AESL_token != "[[[runtime]]]")
            exit(1);
        }
      }
  
      if (rtl_tv_out_file.good()) {
        rtl_tv_out_file >> AESL_token; 
        rtl_tv_out_file >> AESL_num;  // transaction number
        if (AESL_token != "[[transaction]]") {
          cerr << "Unexpected token: " << AESL_token << endl;
          exit(1);
        }
        if (atoi(AESL_num.c_str()) == AESL_transaction_pc) {
          std::vector<sc_bv<32> > p1_pc_buffer(5000);
          int i = 0;

          rtl_tv_out_file >> AESL_token; //data
          while (AESL_token != "[[/transaction]]"){

            RTLOutputCheckAndReplacement(AESL_token, "p1");
  
            // push token into output port buffer
            if (AESL_token != "") {
              p1_pc_buffer[i] = AESL_token.c_str();;
              i++;
            }
  
            rtl_tv_out_file >> AESL_token; //data or [[/transaction]]
            if (AESL_token == "[[[/runtime]]]" || rtl_tv_out_file.eof())
              exit(1);
          }
          if (i > 0) {{
            int i = 0;
            for (int j = 0, e = 5000; j < e; j += 1, ++i) {
            ((int*)__xlx_apatb_param_output)[j] = p1_pc_buffer[i].to_int64();
          }}}
        } // end transaction
      } // end file is good
    } // end post check logic bolck
  
    AESL_transaction_pc++;
    return ;
  }
static unsigned AESL_transaction;
static AESL_FILE_HANDLER aesl_fh;
static INTER_TCL_FILE tcl_file(INTER_TCL);
std::vector<char> __xlx_sprintf_buffer(1024);
CodeState = ENTER_WRAPC;
//p0
aesl_fh.touch(AUTOTB_TVIN_p0);
aesl_fh.touch(AUTOTB_TVOUT_p0);
//p1
aesl_fh.touch(AUTOTB_TVIN_p1);
aesl_fh.touch(AUTOTB_TVOUT_p1);
//input_chunk
aesl_fh.touch(AUTOTB_TVIN_input_chunk);
aesl_fh.touch(AUTOTB_TVOUT_input_chunk);
//chunkSize
aesl_fh.touch(AUTOTB_TVIN_chunkSize);
aesl_fh.touch(AUTOTB_TVOUT_chunkSize);
//output
aesl_fh.touch(AUTOTB_TVIN_output);
aesl_fh.touch(AUTOTB_TVOUT_output);
CodeState = DUMP_INPUTS;
unsigned __xlx_offset_byte_param_input_chunk = 0;
// print p0 Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVIN_p0, __xlx_sprintf_buffer.data());
  {  __xlx_offset_byte_param_input_chunk = 0*1;
  if (__xlx_apatb_param_input_chunk) {
    for (int j = 0  - 0, e = 10000 - 0; j != e; ++j) {
sc_bv<8> __xlx_tmp_lv = ((char*)__xlx_apatb_param_input_chunk)[j];

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVIN_p0, __xlx_sprintf_buffer.data()); 
      }
  }
}
  tcl_file.set_num(10000, &tcl_file.p0_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVIN_p0, __xlx_sprintf_buffer.data());
}
unsigned __xlx_offset_byte_param_output = 0;
// print p1 Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVIN_p1, __xlx_sprintf_buffer.data());
  {  __xlx_offset_byte_param_output = 0*4;
  if (__xlx_apatb_param_output) {
    for (int j = 0  - 0, e = 5000 - 0; j != e; ++j) {
sc_bv<32> __xlx_tmp_lv = ((int*)__xlx_apatb_param_output)[j];

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVIN_p1, __xlx_sprintf_buffer.data()); 
      }
  }
}
  tcl_file.set_num(5000, &tcl_file.p1_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVIN_p1, __xlx_sprintf_buffer.data());
}
// print input_chunk Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVIN_input_chunk, __xlx_sprintf_buffer.data());
  {
    sc_bv<64> __xlx_tmp_lv = __xlx_offset_byte_param_input_chunk;

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVIN_input_chunk, __xlx_sprintf_buffer.data()); 
  }
  tcl_file.set_num(1, &tcl_file.input_chunk_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVIN_input_chunk, __xlx_sprintf_buffer.data());
}
// print chunkSize Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVIN_chunkSize, __xlx_sprintf_buffer.data());
  {
    sc_bv<32> __xlx_tmp_lv = *((int*)&__xlx_apatb_param_chunkSize);

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVIN_chunkSize, __xlx_sprintf_buffer.data()); 
  }
  tcl_file.set_num(1, &tcl_file.chunkSize_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVIN_chunkSize, __xlx_sprintf_buffer.data());
}
// print output Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVIN_output, __xlx_sprintf_buffer.data());
  {
    sc_bv<64> __xlx_tmp_lv = __xlx_offset_byte_param_output;

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVIN_output, __xlx_sprintf_buffer.data()); 
  }
  tcl_file.set_num(1, &tcl_file.output_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVIN_output, __xlx_sprintf_buffer.data());
}
CodeState = CALL_C_DUT;
lzw_hw_streams_hw_stub_wrapper(__xlx_apatb_param_input_chunk, __xlx_apatb_param_chunkSize, __xlx_apatb_param_output);
CodeState = DUMP_OUTPUTS;
// print p1 Transactions
{
  sprintf(__xlx_sprintf_buffer.data(), "[[transaction]] %d\n", AESL_transaction);
  aesl_fh.write(AUTOTB_TVOUT_p1, __xlx_sprintf_buffer.data());
  {  __xlx_offset_byte_param_output = 0*4;
  if (__xlx_apatb_param_output) {
    for (int j = 0  - 0, e = 5000 - 0; j != e; ++j) {
sc_bv<32> __xlx_tmp_lv = ((int*)__xlx_apatb_param_output)[j];

    sprintf(__xlx_sprintf_buffer.data(), "%s\n", __xlx_tmp_lv.to_string(SC_HEX).c_str());
    aesl_fh.write(AUTOTB_TVOUT_p1, __xlx_sprintf_buffer.data()); 
      }
  }
}
  tcl_file.set_num(5000, &tcl_file.p1_depth);
  sprintf(__xlx_sprintf_buffer.data(), "[[/transaction]] \n");
  aesl_fh.write(AUTOTB_TVOUT_p1, __xlx_sprintf_buffer.data());
}
CodeState = DELETE_CHAR_BUFFERS;
AESL_transaction++;
tcl_file.set_num(AESL_transaction , &tcl_file.trans_num);
}
